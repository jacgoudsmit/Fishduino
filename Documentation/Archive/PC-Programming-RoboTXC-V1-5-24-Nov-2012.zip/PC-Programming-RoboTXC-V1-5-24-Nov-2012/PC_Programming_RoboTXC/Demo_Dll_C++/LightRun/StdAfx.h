// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

// eliminate deprecation warnings for the older, less secure functions
#define _CRT_SECURE_NO_DEPRECATE


#include "..\..\Common\Inc\targetver.h"

// Exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN 

// Windows Header Files:
#include <windows.h>

// TODO: reference additional headers your program requires here
#include <stdio.h>
#include <iostream.h>

#include "..\..\Common\Inc\common.h"
#include "..\..\Common\Inc\ROBO_TX_FW.h"
#include "..\..\Common\Inc\ftMscLib.h"
#include "..\..\Common\Inc\ftErrCode.h"
