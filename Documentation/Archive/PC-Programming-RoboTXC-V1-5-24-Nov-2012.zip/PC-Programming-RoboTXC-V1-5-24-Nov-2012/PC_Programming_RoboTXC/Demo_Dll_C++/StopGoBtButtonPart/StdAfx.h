// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

// eliminate deprecation warnings for the older, less secure functions
#define _CRT_SECURE_NO_DEPRECATE


#include "targetver.h"

// Exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN 

// Windows Header Files:
#include <windows.h>

// TODO: reference additional headers your program requires here
#include <stdio.h>
#include <iostream.h>

#include "BT.h"
#include "common.h"
#include "ROBO_TX_FW.h"
#include "ftMscLib.h"
#include "ftErrCode.h"
